//  ViewController.swift
//  Tip//
//  Created by mathews jacob on 2/8/17.
//  Copyright © 2017 xcoding. All rights reserved.
import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var tiplabel: UILabel!
    @IBOutlet weak var totallabel: UILabel!
    
    @IBOutlet weak var tipcontrol: UISegmentedControl!
    @IBOutlet weak var billfield: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func onTap(_ sender: Any) {
        
        view.endEditing(true)
    }
    
    @IBAction func calctip(_ sender: Any) {
        
        let tippercentage = [0.18, 0.2, 0.25]
        
        
        let bill = Double(billfield.text!) ?? 0
        let tip = bill * tippercentage[tipcontrol.selectedSegmentIndex]
        let _total = bill + tip
        tiplabel.text = String (format: "$%.2f", tip )
       totallabel.text = String (format: "$%.2f", _total )
       // tiplabel.text="$\(tip)"
       // totallabel.text="$\(_total)"
        
    }
    
}

